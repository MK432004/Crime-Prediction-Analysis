
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.cluster import KMeans

# Load and clean data
data = pd.read_csv("MCI_2014_to_2019.csv")
data['reporteddayofweek'] = data['reporteddayofweek'].str.strip()
data['Neighbourhood'] = data['Neighbourhood'].str.strip()
data['MCI'] = data['MCI'].str.strip()

# Label encode categorical features
le_day = LabelEncoder()
le_neigh = LabelEncoder()
le_mci = LabelEncoder()

data['day_encoded'] = le_day.fit_transform(data['reporteddayofweek'])
data['neigh_encoded'] = le_neigh.fit_transform(data['Neighbourhood'])
data['mci_encoded'] = le_mci.fit_transform(data['MCI'])

# Train model
X = data[['day_encoded', 'reportedhour', 'neigh_encoded', 'mci_encoded']]
model = KMeans(n_clusters=4, random_state=42, n_init=10)
model.fit(X)

# Mapping cluster to its common crime, hour, area
cluster_descriptions = {
    0: {'crime': 'Break and Enter', 'hour': 4, 'area': 'Kensington-Chinatown'},
    1: {'crime': 'Assault', 'hour': 20, 'area': 'Moss Park'},
    2: {'crime': 'Auto Theft', 'hour': 3, 'area': 'West Humber-Clairville'},
    3: {'crime': 'Theft Over', 'hour': 18, 'area': 'Bay Street Corridor'}
}

def predict_cluster(day, hour, neighbourhood, mci):
    # Clean input
    day = day.strip()
    neighbourhood = neighbourhood.strip()
    mci = mci.strip()

    # Encode input
    try:
        day_enc = le_day.transform([day])[0]
        neigh_enc = le_neigh.transform([neighbourhood])[0]
        mci_enc = le_mci.transform([mci])[0]
    except:
        return "Error: Please enter valid values."

    # Predict
    pred_cluster = model.predict([[day_enc, int(hour), neigh_enc, mci_enc]])[0]
    desc = cluster_descriptions.get(pred_cluster)
    if desc:
        return f"Predicted crime type: {desc['crime']}, likely area: {desc['area']}, peak hour: {desc['hour']}:00"
    else:
        return f"Cluster {pred_cluster}"
