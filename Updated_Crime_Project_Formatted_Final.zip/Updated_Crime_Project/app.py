
from flask import Flask, render_template, request
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.cluster import KMeans

app = Flask(__name__)

# Load and preprocess data
df = pd.read_csv("MCI_2014_to_2019.csv")
df.dropna(subset=['reporteddayofweek', 'reportedhour', 'Neighbourhood', 'MCI'], inplace=True)

df['reporteddayofweek'] = df['reporteddayofweek'].str.strip().str.title()
df['Neighbourhood'] = df['Neighbourhood'].str.strip()
df['MCI'] = df['MCI'].str.strip().str.title()

# Fit LabelEncoders
le_day = LabelEncoder()
le_day.fit(df['reporteddayofweek'].unique())

le_neigh = LabelEncoder()
le_neigh.fit(df['Neighbourhood'].unique())

le_mci = LabelEncoder()
le_mci.fit(df['MCI'].unique())

# Encode training data
df['day_enc'] = le_day.transform(df['reporteddayofweek'])
df['neigh_enc'] = le_neigh.transform(df['Neighbourhood'])
df['mci_enc'] = le_mci.transform(df['MCI'])

X = df[['day_enc', 'reportedhour', 'neigh_enc', 'mci_enc']]

# Train the model
kmeans = KMeans(n_clusters=4, random_state=42)
kmeans.fit(X)

# Reverse cluster labels to crime types (example mapping)
cluster_labels = {
    0: "Assault",
    1: "Break And Enter",
    2: "Auto Theft",
    3: "Theft Over"
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        day = request.form['day'].strip().title()
        hour = int(request.form['hour'])
        neighbourhood = request.form['neighbourhood'].strip()
        mci = request.form['mci'].strip().title()

        # Validate entries before transform
        if day not in le_day.classes_:
            raise ValueError(f"Invalid day: {day}")
        if neighbourhood not in le_neigh.classes_:
            raise ValueError(f"Invalid neighbourhood: {neighbourhood}")
        if mci not in le_mci.classes_:
            raise ValueError(f"Invalid MCI: {mci}")

        day_enc = le_day.transform([day])[0]
        neigh_enc = le_neigh.transform([neighbourhood])[0]
        mci_enc = le_mci.transform([mci])[0]

        input_data = [[day_enc, hour, neigh_enc, mci_enc]]
        cluster = kmeans.predict(input_data)[0]
        crime_type = cluster_labels.get(cluster, "Unknown Crime")

        result_text = f"Likely crime is {crime_type} in {neighbourhood} around {hour}:00"

        return render_template("index.html", result=result_text)

    except Exception as e:
        return render_template("index.html", result=f"Error: {str(e)}")

if __name__ == '__main__':
    app.run(debug=True)

@app.route("/chart-data")
def get_chart_data():
    import pandas as pd
    import json
    from flask import request

    df = pd.read_csv("MCI_2014_to_2019.csv")
    chart_type = request.args.get("type")

    if chart_type == "day":
        counts = df["reporteddayofweek"].value_counts().sort_index()
        return jsonify({
            "labels": list(counts.index),
            "values": list(counts.values),
            "label": "Crimes by Day"
        })
    elif chart_type == "neighbourhood":
        counts = df["Neighbourhood"].value_counts().head(10)
        return jsonify({
            "labels": list(counts.index),
            "values": list(counts.values),
            "label": "Top 10 Neighbourhoods"
        })
    elif chart_type == "year":
        counts = df["occurrenceyear"].value_counts().sort_index()
        return jsonify({
            "labels": list(counts.index),
            "values": list(counts.values),
            "label": "Crimes by Year"
        })
    return jsonify({"labels": [], "values": [], "label": "Unknown"})


@app.route("/show_chart", methods=["POST"])
def show_chart():
    chart_type = request.form.get("chart_type")
    data_type = request.form.get("data_type")

    if not chart_type or not data_type:
        return render_template("chart.html", result="Error: Please select options.", labels=[], values=[], chart_type="bar")

    # Prepare data
    if data_type == "day":
        grouped = df["reporteddayofweek"].value_counts()
    elif data_type == "neighbourhood":
        grouped = df["Hood_ID"].value_counts()
    elif data_type == "year":
        grouped = df["occurrencedate"].str[:4].value_counts()
    else:
        return render_template("chart.html", result="Error: Invalid data type", labels=[], values=[], chart_type=chart_type)

    labels = list(grouped.index.astype(str))
    values = list(grouped.values)

    return render_template("chart.html", labels=labels, values=values, chart_type=chart_type)
